# Angular CLI Template

This template was generated with [Angular CLI](https://github.com/angular/angular-cli).

## Running `ng` commands

On the terminal on your bottom right there is a + you can click to open a new tab in it you can write any commands you want with:

```
yarn ng <your command>
```
