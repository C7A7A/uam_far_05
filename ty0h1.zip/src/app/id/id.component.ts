import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-id",
  templateUrl: "./id.component.html",
  styleUrls: ["./id.component.css"]
})
export class IdComponent implements OnInit {
  primeNumber = Date.now();

  public generateID(): void {
    this.primeNumber = Date.now();
  }

  constructor() {}

  ngOnInit(): void {}
}
